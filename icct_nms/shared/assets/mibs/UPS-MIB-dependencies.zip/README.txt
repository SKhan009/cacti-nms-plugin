UPS-MIB offline dependency set (RFC 1628)

Extract this ZIP, then select these four files together in MIB Repository > Upload:
  UPS-MIB.txt
  SNMPv2-SMI.txt
  SNMPv2-TC.txt
  SNMPv2-CONF.txt

The plugin also resolves these standard dependencies locally when only UPS-MIB.txt is selected.
Review validation results before choosing Save/Proceed. No device is polled during validation.
A valid MIB describes possible objects; it does not prove that your UPS implements them.
Vendor extensions may require additional modules named in their IMPORTS clauses.
Source revisions, hashes and the documented import correction are in standard-mibs-sources.json.
